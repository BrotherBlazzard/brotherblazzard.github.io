﻿namespace MegaEscritorioDesktop
{
    partial class DeskOrderView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.OrderDateLabel = new System.Windows.Forms.Label();
            this.orderDate = new System.Windows.Forms.Label();
            this.DeskWidthLabel = new System.Windows.Forms.Label();
            this.DeskDepthLabel = new System.Windows.Forms.Label();
            this.deskWidth = new System.Windows.Forms.Label();
            this.deskDepth = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.NumberOfDrawersLabel = new System.Windows.Forms.Label();
            this.RushOrderLabel = new System.Windows.Forms.Label();
            this.DesktopMaterialLabel = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.drawers = new System.Windows.Forms.Label();
            this.material = new System.Windows.Forms.Label();
            this.rushDays = new System.Windows.Forms.Label();
            this.quoteTotal = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // OrderDateLabel
            // 
            this.OrderDateLabel.AutoSize = true;
            this.OrderDateLabel.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OrderDateLabel.Location = new System.Drawing.Point(87, 22);
            this.OrderDateLabel.Name = "OrderDateLabel";
            this.OrderDateLabel.Size = new System.Drawing.Size(112, 23);
            this.OrderDateLabel.TabIndex = 0;
            this.OrderDateLabel.Text = "Quote Date:";
            // 
            // orderDate
            // 
            this.orderDate.AutoSize = true;
            this.orderDate.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.orderDate.ForeColor = System.Drawing.Color.Blue;
            this.orderDate.Location = new System.Drawing.Point(217, 22);
            this.orderDate.Name = "orderDate";
            this.orderDate.Size = new System.Drawing.Size(107, 23);
            this.orderDate.TabIndex = 1;
            this.orderDate.Text = "placeholder";
            // 
            // DeskWidthLabel
            // 
            this.DeskWidthLabel.AutoSize = true;
            this.DeskWidthLabel.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeskWidthLabel.Location = new System.Drawing.Point(87, 66);
            this.DeskWidthLabel.Name = "DeskWidthLabel";
            this.DeskWidthLabel.Size = new System.Drawing.Size(112, 23);
            this.DeskWidthLabel.TabIndex = 2;
            this.DeskWidthLabel.Text = "Desk Width:";
            // 
            // DeskDepthLabel
            // 
            this.DeskDepthLabel.AutoSize = true;
            this.DeskDepthLabel.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeskDepthLabel.Location = new System.Drawing.Point(85, 110);
            this.DeskDepthLabel.Name = "DeskDepthLabel";
            this.DeskDepthLabel.Size = new System.Drawing.Size(114, 23);
            this.DeskDepthLabel.TabIndex = 3;
            this.DeskDepthLabel.Text = "Desk Depth:";
            // 
            // deskWidth
            // 
            this.deskWidth.AutoSize = true;
            this.deskWidth.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deskWidth.ForeColor = System.Drawing.Color.Blue;
            this.deskWidth.Location = new System.Drawing.Point(217, 68);
            this.deskWidth.Name = "deskWidth";
            this.deskWidth.Size = new System.Drawing.Size(107, 23);
            this.deskWidth.TabIndex = 4;
            this.deskWidth.Text = "placeholder";
            // 
            // deskDepth
            // 
            this.deskDepth.AutoSize = true;
            this.deskDepth.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deskDepth.ForeColor = System.Drawing.Color.Blue;
            this.deskDepth.Location = new System.Drawing.Point(217, 114);
            this.deskDepth.Name = "deskDepth";
            this.deskDepth.Size = new System.Drawing.Size(107, 23);
            this.deskDepth.TabIndex = 5;
            this.deskDepth.Text = "placeholder";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(369, 344);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(108, 42);
            this.button1.TabIndex = 6;
            this.button1.Text = "Close";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // NumberOfDrawersLabel
            // 
            this.NumberOfDrawersLabel.AutoSize = true;
            this.NumberOfDrawersLabel.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NumberOfDrawersLabel.Location = new System.Drawing.Point(17, 154);
            this.NumberOfDrawersLabel.Name = "NumberOfDrawersLabel";
            this.NumberOfDrawersLabel.Size = new System.Drawing.Size(182, 23);
            this.NumberOfDrawersLabel.TabIndex = 7;
            this.NumberOfDrawersLabel.Text = "Number of Drawers:";
            // 
            // RushOrderLabel
            // 
            this.RushOrderLabel.AutoSize = true;
            this.RushOrderLabel.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RushOrderLabel.Location = new System.Drawing.Point(28, 242);
            this.RushOrderLabel.Name = "RushOrderLabel";
            this.RushOrderLabel.Size = new System.Drawing.Size(171, 23);
            this.RushOrderLabel.TabIndex = 8;
            this.RushOrderLabel.Text = "Rush Order (days):";
            // 
            // DesktopMaterialLabel
            // 
            this.DesktopMaterialLabel.AutoSize = true;
            this.DesktopMaterialLabel.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DesktopMaterialLabel.Location = new System.Drawing.Point(43, 198);
            this.DesktopMaterialLabel.Name = "DesktopMaterialLabel";
            this.DesktopMaterialLabel.Size = new System.Drawing.Size(156, 23);
            this.DesktopMaterialLabel.TabIndex = 9;
            this.DesktopMaterialLabel.Text = "Desktop Material:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(44, 305);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(155, 25);
            this.label3.TabIndex = 10;
            this.label3.Text = "Quote Amount:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Navy;
            this.panel1.Location = new System.Drawing.Point(12, 282);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(465, 3);
            this.panel1.TabIndex = 11;
            // 
            // drawers
            // 
            this.drawers.AutoSize = true;
            this.drawers.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.drawers.ForeColor = System.Drawing.Color.Blue;
            this.drawers.Location = new System.Drawing.Point(217, 154);
            this.drawers.Name = "drawers";
            this.drawers.Size = new System.Drawing.Size(107, 23);
            this.drawers.TabIndex = 12;
            this.drawers.Text = "placeholder";
            // 
            // material
            // 
            this.material.AutoSize = true;
            this.material.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.material.ForeColor = System.Drawing.Color.Blue;
            this.material.Location = new System.Drawing.Point(217, 198);
            this.material.Name = "material";
            this.material.Size = new System.Drawing.Size(107, 23);
            this.material.TabIndex = 13;
            this.material.Text = "placeholder";
            // 
            // rushDays
            // 
            this.rushDays.AutoSize = true;
            this.rushDays.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rushDays.ForeColor = System.Drawing.Color.Blue;
            this.rushDays.Location = new System.Drawing.Point(217, 242);
            this.rushDays.Name = "rushDays";
            this.rushDays.Size = new System.Drawing.Size(107, 23);
            this.rushDays.TabIndex = 14;
            this.rushDays.Text = "placeholder";
            // 
            // quoteTotal
            // 
            this.quoteTotal.AutoSize = true;
            this.quoteTotal.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quoteTotal.ForeColor = System.Drawing.Color.Blue;
            this.quoteTotal.Location = new System.Drawing.Point(216, 305);
            this.quoteTotal.Name = "quoteTotal";
            this.quoteTotal.Size = new System.Drawing.Size(120, 25);
            this.quoteTotal.TabIndex = 15;
            this.quoteTotal.Text = "placeholder";
            // 
            // DeskOrderView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(501, 422);
            this.Controls.Add(this.quoteTotal);
            this.Controls.Add(this.rushDays);
            this.Controls.Add(this.material);
            this.Controls.Add(this.drawers);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.DesktopMaterialLabel);
            this.Controls.Add(this.RushOrderLabel);
            this.Controls.Add(this.NumberOfDrawersLabel);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.deskDepth);
            this.Controls.Add(this.deskWidth);
            this.Controls.Add(this.DeskDepthLabel);
            this.Controls.Add(this.DeskWidthLabel);
            this.Controls.Add(this.orderDate);
            this.Controls.Add(this.OrderDateLabel);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "DeskOrderView";
            this.Text = "DeskOrderView";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label OrderDateLabel;
        private System.Windows.Forms.Label orderDate;
        private System.Windows.Forms.Label DeskWidthLabel;
        private System.Windows.Forms.Label DeskDepthLabel;
        private System.Windows.Forms.Label deskWidth;
        private System.Windows.Forms.Label deskDepth;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label NumberOfDrawersLabel;
        private System.Windows.Forms.Label RushOrderLabel;
        private System.Windows.Forms.Label DesktopMaterialLabel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label drawers;
        private System.Windows.Forms.Label material;
        private System.Windows.Forms.Label rushDays;
        private System.Windows.Forms.Label quoteTotal;
    }
}