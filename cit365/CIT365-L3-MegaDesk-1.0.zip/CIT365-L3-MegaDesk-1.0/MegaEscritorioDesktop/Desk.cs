﻿using System;

namespace MegaEscritorioDesktop
{
    class Desk
    {
        public int width { get; set; }
        public int depth { get; set; }
        public int numDrawers { get; set; }
        public string desktopMaterial { get; set; }
    }
}
