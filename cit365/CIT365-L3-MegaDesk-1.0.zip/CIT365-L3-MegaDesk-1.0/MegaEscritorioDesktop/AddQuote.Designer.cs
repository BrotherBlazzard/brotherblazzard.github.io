﻿namespace MegaEscritorioDesktop
{
    partial class AddQuote
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.widthLabel = new System.Windows.Forms.Label();
            this.depthLabel = new System.Windows.Forms.Label();
            this.numDrawersLabel = new System.Windows.Forms.Label();
            this.widthTextBox = new System.Windows.Forms.TextBox();
            this.depthTextBox = new System.Windows.Forms.TextBox();
            this.numDrawersComboBox = new System.Windows.Forms.ComboBox();
            this.addDeskHeading = new System.Windows.Forms.Label();
            this.desktopMaterialComboBox = new System.Windows.Forms.ComboBox();
            this.materialLabel = new System.Windows.Forms.Label();
            this.rushOrderLabel = new System.Windows.Forms.Label();
            this.addDeskButton = new System.Windows.Forms.Button();
            this.rushOrder = new System.Windows.Forms.Panel();
            this.rushSevenRadio = new System.Windows.Forms.RadioButton();
            this.rushFiveRadio = new System.Windows.Forms.RadioButton();
            this.rushThreeRadio = new System.Windows.Forms.RadioButton();
            this.rushNoneRadio = new System.Windows.Forms.RadioButton();
            this.titleLinePanel = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.rushOrder.SuspendLayout();
            this.SuspendLayout();
            // 
            // widthLabel
            // 
            this.widthLabel.AutoSize = true;
            this.widthLabel.Font = new System.Drawing.Font("Ubuntu Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.widthLabel.Location = new System.Drawing.Point(12, 57);
            this.widthLabel.Name = "widthLabel";
            this.widthLabel.Size = new System.Drawing.Size(429, 23);
            this.widthLabel.TabIndex = 0;
            this.widthLabel.Text = "1. Enter the WIDTH of the desk in inches ( 24\" min; 96\" max )";
            // 
            // depthLabel
            // 
            this.depthLabel.AutoSize = true;
            this.depthLabel.Font = new System.Drawing.Font("Ubuntu Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.depthLabel.Location = new System.Drawing.Point(12, 123);
            this.depthLabel.Name = "depthLabel";
            this.depthLabel.Size = new System.Drawing.Size(429, 23);
            this.depthLabel.TabIndex = 1;
            this.depthLabel.Text = "2. Enter the DEPTH of the desk in inches ( 12\" min; 56\" max )";
            // 
            // numDrawersLabel
            // 
            this.numDrawersLabel.AutoSize = true;
            this.numDrawersLabel.Font = new System.Drawing.Font("Ubuntu Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numDrawersLabel.Location = new System.Drawing.Point(12, 189);
            this.numDrawersLabel.Name = "numDrawersLabel";
            this.numDrawersLabel.Size = new System.Drawing.Size(252, 23);
            this.numDrawersLabel.TabIndex = 2;
            this.numDrawersLabel.Text = "3. Select the number of DRAWERS:";
            // 
            // widthTextBox
            // 
            this.widthTextBox.Font = new System.Drawing.Font("Ubuntu Light", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.widthTextBox.Location = new System.Drawing.Point(51, 88);
            this.widthTextBox.MaxLength = 2;
            this.widthTextBox.Name = "widthTextBox";
            this.widthTextBox.Size = new System.Drawing.Size(46, 29);
            this.widthTextBox.TabIndex = 0;
            this.widthTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.widthTextBox.WordWrap = false;
            this.widthTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.widthTextBox_KeyPress);
            this.widthTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.widthTextBox_Validating);
            // 
            // depthTextBox
            // 
            this.depthTextBox.Font = new System.Drawing.Font("Ubuntu Light", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.depthTextBox.Location = new System.Drawing.Point(51, 149);
            this.depthTextBox.MaxLength = 2;
            this.depthTextBox.Name = "depthTextBox";
            this.depthTextBox.Size = new System.Drawing.Size(46, 29);
            this.depthTextBox.TabIndex = 1;
            this.depthTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.depthTextBox.WordWrap = false;
            this.depthTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.depthTextBox_KeyPress);
            // 
            // numDrawersComboBox
            // 
            this.numDrawersComboBox.DisplayMember = "Items";
            this.numDrawersComboBox.FormattingEnabled = true;
            this.numDrawersComboBox.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7"});
            this.numDrawersComboBox.Location = new System.Drawing.Point(51, 224);
            this.numDrawersComboBox.Name = "numDrawersComboBox";
            this.numDrawersComboBox.Size = new System.Drawing.Size(46, 25);
            this.numDrawersComboBox.TabIndex = 2;
            // 
            // addDeskHeading
            // 
            this.addDeskHeading.AutoSize = true;
            this.addDeskHeading.Font = new System.Drawing.Font("Ubuntu Condensed", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addDeskHeading.ForeColor = System.Drawing.Color.RoyalBlue;
            this.addDeskHeading.Location = new System.Drawing.Point(12, 4);
            this.addDeskHeading.Name = "addDeskHeading";
            this.addDeskHeading.Size = new System.Drawing.Size(205, 39);
            this.addDeskHeading.TabIndex = 3;
            this.addDeskHeading.Text = "Add Desk Quote";
            // 
            // desktopMaterialComboBox
            // 
            this.desktopMaterialComboBox.FormattingEnabled = true;
            this.desktopMaterialComboBox.ItemHeight = 17;
            this.desktopMaterialComboBox.Location = new System.Drawing.Point(51, 288);
            this.desktopMaterialComboBox.Name = "desktopMaterialComboBox";
            this.desktopMaterialComboBox.Size = new System.Drawing.Size(128, 25);
            this.desktopMaterialComboBox.TabIndex = 3;
            // 
            // materialLabel
            // 
            this.materialLabel.AutoSize = true;
            this.materialLabel.Font = new System.Drawing.Font("Ubuntu Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.materialLabel.Location = new System.Drawing.Point(12, 255);
            this.materialLabel.Name = "materialLabel";
            this.materialLabel.Size = new System.Drawing.Size(240, 23);
            this.materialLabel.TabIndex = 5;
            this.materialLabel.Text = "4.  Select the desktop MATERIAL:";
            // 
            // rushOrderLabel
            // 
            this.rushOrderLabel.AutoSize = true;
            this.rushOrderLabel.Font = new System.Drawing.Font("Ubuntu Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rushOrderLabel.Location = new System.Drawing.Point(12, 321);
            this.rushOrderLabel.Name = "rushOrderLabel";
            this.rushOrderLabel.Size = new System.Drawing.Size(132, 23);
            this.rushOrderLabel.TabIndex = 6;
            this.rushOrderLabel.Text = "5.  RUSH ORDER?";
            // 
            // addDeskButton
            // 
            this.addDeskButton.Font = new System.Drawing.Font("Ubuntu", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addDeskButton.Location = new System.Drawing.Point(127, 410);
            this.addDeskButton.Name = "addDeskButton";
            this.addDeskButton.Size = new System.Drawing.Size(172, 46);
            this.addDeskButton.TabIndex = 7;
            this.addDeskButton.Text = "Submit Order";
            this.addDeskButton.UseVisualStyleBackColor = true;
            this.addDeskButton.Click += new System.EventHandler(this.addDeskButton_Click);
            // 
            // rushOrder
            // 
            this.rushOrder.BackColor = System.Drawing.Color.Silver;
            this.rushOrder.Controls.Add(this.rushSevenRadio);
            this.rushOrder.Controls.Add(this.rushFiveRadio);
            this.rushOrder.Controls.Add(this.rushThreeRadio);
            this.rushOrder.Controls.Add(this.rushNoneRadio);
            this.rushOrder.Font = new System.Drawing.Font("Ubuntu Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rushOrder.Location = new System.Drawing.Point(51, 352);
            this.rushOrder.Name = "rushOrder";
            this.rushOrder.Size = new System.Drawing.Size(359, 29);
            this.rushOrder.TabIndex = 8;
            // 
            // rushSevenRadio
            // 
            this.rushSevenRadio.AutoSize = true;
            this.rushSevenRadio.Location = new System.Drawing.Point(249, 3);
            this.rushSevenRadio.Name = "rushSevenRadio";
            this.rushSevenRadio.Size = new System.Drawing.Size(57, 23);
            this.rushSevenRadio.TabIndex = 3;
            this.rushSevenRadio.TabStop = true;
            this.rushSevenRadio.Text = "7 day";
            this.rushSevenRadio.UseVisualStyleBackColor = true;
            // 
            // rushFiveRadio
            // 
            this.rushFiveRadio.AutoSize = true;
            this.rushFiveRadio.Location = new System.Drawing.Point(171, 3);
            this.rushFiveRadio.Name = "rushFiveRadio";
            this.rushFiveRadio.Size = new System.Drawing.Size(57, 23);
            this.rushFiveRadio.TabIndex = 2;
            this.rushFiveRadio.TabStop = true;
            this.rushFiveRadio.Text = "5 day";
            this.rushFiveRadio.UseVisualStyleBackColor = true;
            // 
            // rushThreeRadio
            // 
            this.rushThreeRadio.AccessibleRole = System.Windows.Forms.AccessibleRole.ButtonDropDown;
            this.rushThreeRadio.AutoSize = true;
            this.rushThreeRadio.Location = new System.Drawing.Point(92, 3);
            this.rushThreeRadio.Name = "rushThreeRadio";
            this.rushThreeRadio.Size = new System.Drawing.Size(57, 23);
            this.rushThreeRadio.TabIndex = 1;
            this.rushThreeRadio.TabStop = true;
            this.rushThreeRadio.Text = "3 day";
            this.rushThreeRadio.UseVisualStyleBackColor = true;
            // 
            // rushNoneRadio
            // 
            this.rushNoneRadio.AutoSize = true;
            this.rushNoneRadio.Location = new System.Drawing.Point(11, 3);
            this.rushNoneRadio.Name = "rushNoneRadio";
            this.rushNoneRadio.Size = new System.Drawing.Size(58, 23);
            this.rushNoneRadio.TabIndex = 0;
            this.rushNoneRadio.TabStop = true;
            this.rushNoneRadio.Text = "None";
            this.rushNoneRadio.UseVisualStyleBackColor = true;
            // 
            // titleLinePanel
            // 
            this.titleLinePanel.BackColor = System.Drawing.Color.Silver;
            this.titleLinePanel.Location = new System.Drawing.Point(16, 46);
            this.titleLinePanel.Name = "titleLinePanel";
            this.titleLinePanel.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.titleLinePanel.Size = new System.Drawing.Size(430, 3);
            this.titleLinePanel.TabIndex = 9;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Silver;
            this.panel2.Location = new System.Drawing.Point(17, 389);
            this.panel2.Name = "panel2";
            this.panel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.panel2.Size = new System.Drawing.Size(430, 3);
            this.panel2.TabIndex = 10;
            // 
            // AddQuote
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(459, 468);
            this.ControlBox = false;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.titleLinePanel);
            this.Controls.Add(this.rushOrder);
            this.Controls.Add(this.addDeskButton);
            this.Controls.Add(this.rushOrderLabel);
            this.Controls.Add(this.desktopMaterialComboBox);
            this.Controls.Add(this.materialLabel);
            this.Controls.Add(this.addDeskHeading);
            this.Controls.Add(this.numDrawersComboBox);
            this.Controls.Add(this.depthTextBox);
            this.Controls.Add(this.widthTextBox);
            this.Controls.Add(this.numDrawersLabel);
            this.Controls.Add(this.depthLabel);
            this.Controls.Add(this.widthLabel);
            this.Font = new System.Drawing.Font("Ubuntu Condensed", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AddQuote";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Mega Escritorio .:|:.";
            this.rushOrder.ResumeLayout(false);
            this.rushOrder.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label widthLabel;
        private System.Windows.Forms.Label depthLabel;
        private System.Windows.Forms.Label numDrawersLabel;
        private System.Windows.Forms.TextBox widthTextBox;
        private System.Windows.Forms.TextBox depthTextBox;
        private System.Windows.Forms.ComboBox numDrawersComboBox;
        private System.Windows.Forms.Label addDeskHeading;
        private System.Windows.Forms.ComboBox desktopMaterialComboBox;
        private System.Windows.Forms.Label materialLabel;
        private System.Windows.Forms.Label rushOrderLabel;
        private System.Windows.Forms.Button addDeskButton;
        private System.Windows.Forms.Panel rushOrder;
        private System.Windows.Forms.Panel titleLinePanel;
        private System.Windows.Forms.RadioButton rushSevenRadio;
        private System.Windows.Forms.RadioButton rushFiveRadio;
        private System.Windows.Forms.RadioButton rushThreeRadio;
        private System.Windows.Forms.RadioButton rushNoneRadio;
        private System.Windows.Forms.Panel panel2;
    }
}