﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Windows.Forms;

namespace MegaEscritorioDesktop
{
    public partial class AddQuote : Form
    {
        #region Declarations
        // Declare constants - desktop dimension limits
          int MINWIDTH = 24;
          int MAXWIDTH = 96;
          int MINDEPTH = 12;
          int MAXDEPTH = 56;

        // Declaration of member, working variables
          int width = 0;
          int depth = 0; 
          int drawers = 0; // number of desk drawers
          string material = ""; // desktop material selection
          int rushOrderDays = 0; // rush order selection in days
        #endregion

        public AddQuote()
        {
            InitializeComponent();
        }

        private void widthTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Another viable option is to use a control like the NumericUpDown to limit input
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }      
        }

        private void depthTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Or use Validating event
            // Another viable option is to use a control like the NumericUpDown to limit input
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void widthTextBox_Validating(object sender, CancelEventArgs e)
        {
            int width;
            if (int.TryParse(widthTextBox.Text, out width))
            {
                if (width < 24 || width > 96)
                {
                    MessageBox.Show("Please enter a width from 24 to 96 inches.");
                    widthTextBox.Text = "";
                    widthTextBox.BackColor = Color.LightSalmon;
                    widthTextBox.Focus();
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid width measurement as a whole number.");
                widthTextBox.Text = "";
                widthTextBox.BackColor = Color.LightSalmon;
                widthTextBox.Focus();
            }
        }

        private void addDeskButton_Click(object sender, EventArgs e)
        {
            // Input
            try
            {
                width = int.Parse(widthTextBox.Text);
                depth = int.Parse(depthTextBox.Text);

                if (width < MINWIDTH || width > MAXWIDTH)
                {
                    MessageBox.Show("Please enter a width from 24 to 96 inches.");
                    return;
                }

                if (depth < MINDEPTH || depth > MAXDEPTH)
                {
                    MessageBox.Show("Please enter a depth from 12 to 56 inches");
                    depthTextBox.Text = "";
                    depthTextBox.BackColor = Color.LightSalmon;
                    depthTextBox.Focus();
                    return;
                }

                // get the number of drawers from the combobox
                //bool parseOK = int.TryParse(numDrawersComboBox.SelectedValue.ToString(), out drawers);
                drawers = int.Parse(numDrawersComboBox.SelectedItem.ToString());
                material = desktopMaterialComboBox.SelectedItem.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Check Input");
            }

            // Create new desk object
            Desk newDesk = new Desk()
            {
                width = width,
                depth = depth,
                numDrawers = drawers,
                desktopMaterial = material
            };
            
            // Get rush order selection
            // consider using LINQ
            if (rushThreeRadio.Checked)
            {
                rushOrderDays = 3;
            }
            if (rushFiveRadio.Checked)
            {
                rushOrderDays = 5;
            }
            if (rushSevenRadio.Checked)
            {
                rushOrderDays = 7;
            }

            // Create new deskOrder object

            DeskOrder newOrder = new DeskOrder(newDesk.width, newDesk.depth, newDesk.numDrawers, newDesk.desktopMaterial, rushOrderDays);

            // calculate quote total, add it to the DeskOrder with the order Date

            newOrder.deskQuote = newOrder.BASEPRICE + newOrder.surfaceCost() + newOrder.drawerCost() + newOrder.surfaceMaterialCost() + newOrder.rushOrderCost();
            newOrder.quoteDate = DateTime.Now;

            try
            {

                // build output string csv
                var dorecord = newOrder.quoteDate + ", " + newDesk.width + ", " + newDesk.depth + ", " + newDesk.numDrawers + ", " + newDesk.desktopMaterial + ", " + rushOrderDays + ", " + newOrder.deskQuote;
                
                // build output JSON



                // Store newOrder into a List object - make deskOrders available to Search
                // List<DeskOrder> deskOrders = new List<DeskOrder>();
                // deskOrders.Add(newOrder);

                // Store deskOrder into file
                
                string cFile = @"quotes.txt";
                if (!File.Exists(cFile))
                {
                    using (StreamWriter sw = File.CreateText("deskorders.txt"))
                    {
                        sw.WriteLine("Mega Escritorio - Desk Orders");
                        sw.WriteLine("********************************");
                    }

                }
                using (StreamWriter sw = File.AppendText("deskorders.txt"))
                {
                    sw.WriteLine(dorecord);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Check Desk Order Output Methods");
            }



            // Show confirmation page on screen
            DeskOrderView newOrderView = new DeskOrderView(newOrder.quoteDate, newDesk.width, newDesk.depth, newDesk.numDrawers, newDesk.desktopMaterial.ToString(), rushOrderDays, newOrder.deskQuote);
            newOrderView.Show();
            this.Close();

        }

       
    }
}
