﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MegaEscritorioDesktop
{
    public partial class DeskOrderView : Form
    {
        public DeskOrderView(DateTime QuoteDate, int width, int depth, int numOfDrawers, string desktopMaterial, int rushOrderDays, int deskQuote)
        {
            InitializeComponent();
            orderDate.Text = QuoteDate.ToString();
            deskWidth.Text = width.ToString() + " inches";
            deskDepth.Text = depth.ToString() + " inches";
            drawers.Text = numOfDrawers.ToString();
            material.Text = desktopMaterial;
            rushDays.Text = rushOrderDays.ToString() + " days";
            quoteTotal.Text = String.Format("{0:C}", deskQuote);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MainMenu mainMenuView = new MainMenu();
            mainMenuView.Show();
            this.Close();
        }
    }
}
